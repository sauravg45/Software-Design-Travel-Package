package com.nymble.assignment.utility;

public enum PassengerSubType {
    PREMIUM,
    GOLD,
    STANDARD;

}
