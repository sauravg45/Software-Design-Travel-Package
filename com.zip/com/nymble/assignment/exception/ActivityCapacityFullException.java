package nymble.assignment.exception;

public class ActivityCapacityFullException extends RuntimeException{

    public ActivityCapacityFullException(String message) {
        super(message);
    }
}
