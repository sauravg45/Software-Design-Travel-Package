package nymble.assignment.exception;

public class TravelPackageFullException extends RuntimeException{
    public TravelPackageFullException(String message) {
        super(message);
    }
}
