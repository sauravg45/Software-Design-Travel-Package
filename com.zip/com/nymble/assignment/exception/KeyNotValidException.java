package nymble.assignment.exception;

public class KeyNotValidException extends RuntimeException{
    public KeyNotValidException(String message) {
        super(message);
    }
}
